package repository

import (
	"context"
	"crypto/rand"
	"database/sql"
	"fmt"
	"math/big"
	"sort"
	"strconv"
	"strings"
	"time"

	"ifragment-backend/internal/model"

	"github.com/jackc/pgx/v5"
	"golang.org/x/sync/errgroup"
)

// EnsureStatsExists inserts default stats for the user if they don't exist
func (db *Database) EnsureStatsExists(ctx context.Context, userID int64) error {
	// Ensure parent user row exists first to satisfy FK constraint
	_, _ = db.Pool.Exec(ctx, `
		INSERT INTO users (telegram_id, username, first_name, last_name, language_code)
		VALUES ($1, '', 'User', '', 'en')
		ON CONFLICT (telegram_id) DO NOTHING
	`, userID)

	query := `
		INSERT INTO user_stats (user_id, days_active, current_streak, total_taps, xp, level, last_active_at, energy, energy_updated_at)
		VALUES ($1, 1, 1, 0, 0, 1, CURRENT_TIMESTAMP, 500, CURRENT_TIMESTAMP)
		ON CONFLICT (user_id) DO NOTHING
	`
	_, err := db.Pool.Exec(ctx, query, userID)
	return err
}

func (db *Database) GetProfileStats(ctx context.Context, userID int64) (*model.ProfileStats, error) {
	if err := db.EnsureStatsExists(ctx, userID); err != nil {
		return nil, err
	}

	query := `
		WITH user_info AS (
			SELECT telegram_id, COALESCE(username, '') as username, COALESCE(first_name, '') as first_name, COALESCE(last_name, '') as last_name, COALESCE(photo_url, '') as photo_url, created_at, is_premium, premium_until 
			FROM users WHERE telegram_id = $1
		),
		reports_count AS (
			SELECT COUNT(DISTINCT username) as count FROM search_logs WHERE user_id = $1
		),
		managed_counts AS (
			SELECT 
				(
					SELECT COUNT(*) FROM managed_groups mg
					LEFT JOIN managed_bots mb ON mg.bot_id = mb.id
					WHERE mg.connected_by_user_id = $1 OR mb.owner_user_id = $1
				) as groups,
				(
					SELECT COUNT(*) FROM managed_channels mc
					LEFT JOIN managed_bots mb ON mc.bot_id = mb.id
					WHERE mc.connected_by_user_id = $1 OR mb.owner_user_id = $1 
					   OR EXISTS (SELECT 1 FROM channel_admins ca WHERE ca.channel_id = mc.id AND ca.telegram_id = $1)
				) as channels
		),
		stats_info AS (
			SELECT us.days_active, us.current_streak, us.total_taps, us.xp, us.level, us.last_active_at,
			       COALESCE(us.emoji_status, '') as emoji_status,
			       COALESCE(us.equipped_border, '') as equipped_border,
			       COALESCE(us.equipped_skin, '') as equipped_skin,
			       COALESCE(us.airdrop_coins, 0) as airdrop_coins,
			       COALESCE(us.total_coins_earned, 0.0) as total_coins_earned,
			       COALESCE(us.energy, 500) as energy,
			       COALESCE(us.energy_updated_at, CURRENT_TIMESTAMP) as energy_updated_at,
			       COALESCE(udb.tapped_coins, 0) as daily_tapped_coins,
			       COALESCE(udb.turbo_used, 0) as turbo_used,
			       COALESCE(udb.full_energy_used, 0) as full_energy_used
			FROM user_stats us
			LEFT JOIN user_daily_boosts udb ON udb.user_id = us.user_id AND udb.day = CURRENT_DATE
			WHERE us.user_id = $1
		)
		SELECT 
			ui.telegram_id,
			ui.username,
			ui.first_name,
			ui.last_name,
			ui.created_at,
			rc.count,
			mc.groups,
			mc.channels,
			si.airdrop_coins,
			si.total_coins_earned,
			COALESCE(GREATEST(si.total_coins_earned - si.airdrop_coins, 0.0), 0.0),
			si.days_active,
			si.current_streak,
			si.total_taps,
			si.xp,
			si.level,
			si.last_active_at,
			ui.is_premium,
			ui.premium_until,
			si.emoji_status,
			si.equipped_border,
			si.equipped_skin,
			si.airdrop_coins,
			si.energy,
			si.energy_updated_at,
			si.daily_tapped_coins,
			si.turbo_used,
			si.full_energy_used,
			ui.photo_url
		FROM stats_info si
		CROSS JOIN user_info ui
		CROSS JOIN reports_count rc
		CROSS JOIN managed_counts mc
	`

	var targetTelegramID int64
	var targetUsername, targetFirstName, targetLastName, dbPhotoURL string
	var memberSince time.Time
	var usernamesAnalyzed, groupsManaged, channelsManaged int
	var frgBalance, totalFrgEarned, totalFrgSpent float64
	var daysActive, currentStreak, totalTaps, xp, level int
	var lastActiveAt time.Time
	var isPremium bool
	var premiumUntil *time.Time
	var emojiStatus, equippedBorder, equippedSkin string
	var airdropCoins float64
	var energy int
	var energyUpdatedAt time.Time
	var dailyTappedCoins float64
	var dailyTurboUsed, dailyFullEnergyUsed int

	err := db.Pool.QueryRow(ctx, query, userID).Scan(
		&targetTelegramID, &targetUsername, &targetFirstName, &targetLastName,
		&memberSince, &usernamesAnalyzed, &groupsManaged, &channelsManaged,
		&frgBalance, &totalFrgEarned, &totalFrgSpent,
		&daysActive, &currentStreak, &totalTaps, &xp, &level, &lastActiveAt,
		&isPremium, &premiumUntil, &emojiStatus, &equippedBorder, &equippedSkin, &airdropCoins,
		&energy, &energyUpdatedAt, &dailyTappedCoins, &dailyTurboUsed, &dailyFullEnergyUsed,
		&dbPhotoURL,
	)
	if err != nil {
		return nil, err
	}

	boosts, _ := db.GetUserBoosts(ctx, userID)
	energyLimitLevel := 1
	if boosts != nil {
		energyLimitLevel = boosts.EnergyLimitLevel
	}
	maxEnergy := 500 + (energyLimitLevel-1)*250
	regen := int(time.Since(energyUpdatedAt).Seconds())
	if regen > 0 {
		energy += regen
		if energy > maxEnergy {
			energy = maxEnergy
		}
	}

	globalRank, _ := db.GetGlobalRankFromDB(ctx, xp)

	return &model.ProfileStats{
		TelegramID:          targetTelegramID,
		Username:            targetUsername,
		FirstName:           targetFirstName,
		LastName:            targetLastName,
		UsernamesAnalyzed:   usernamesAnalyzed,
		GroupsManaged:       groupsManaged,
		ChannelsManaged:     channelsManaged,
		DaysActive:          daysActive,
		CurrentStreak:       currentStreak,
		GlobalRank:          globalRank,
		TotalTaps:           totalTaps,
		TotalFrgEarned:      totalFrgEarned,
		TotalFrgSpent:       totalFrgSpent,
		FrgBalance:          frgBalance,
		MemberSince:         memberSince,
		Level:               level,
		XP:                  xp,
		XPToNextLevel:       GetXPToNextLevel(level),
		IsPremium:           isPremium,
		PremiumUntil:        premiumUntil,
		EmojiStatus:         emojiStatus,
		EquippedBorder:      equippedBorder,
		EquippedSkin:        equippedSkin,
		AirdropCoins:        airdropCoins,
		Energy:              energy,
		EnergyUpdatedAt:     energyUpdatedAt,
		DailyTappedCoins:    dailyTappedCoins,
		DailyTurboUsed:      dailyTurboUsed,
		DailyFullEnergyUsed: dailyFullEnergyUsed,
		ServerNow:           time.Now().Unix(),
		PhotoURL:            dbPhotoURL,
	}, nil
}

func (db *Database) GetGlobalRankFromDB(ctx context.Context, xp int) (int, error) {
	// League thresholds based on frontend config
	leagues := []int{0, 5000, 50000, 500000, 2000000, 10000000, 50000000, 100000000}

	maxXP := 2000000000 // effectively infinity
	for i := len(leagues) - 1; i >= 0; i-- {
		if xp >= leagues[i] {
			if i < len(leagues)-1 {
				maxXP = leagues[i+1]
			}
			break
		}
	}

	var rank int
	// Rank is relative to the user's current league (xp < maxXP)
	// Ignore test/dummy accounts by ensuring user_id > 1000000
	rankQuery := "SELECT COUNT(*) + 1 FROM user_stats WHERE xp > $1 AND xp < $2 AND user_id > 1000000"
	err := db.Pool.QueryRow(ctx, rankQuery, xp, maxXP).Scan(&rank)
	return rank, err
}

var PredefinedAchievements = map[string]int{
	"first_steps":       1,
	"home_base":         1,
	"tap_novice":        1000,
	"mining_machine":    100000,
	"frg_millionaire":   1000000,
	"first_scan":        1,
	"whale_hunter":      100,
	"data_scientist":    500,
	"social_butterfly":  5,
	"army_builder":      50,
	"network_king":      200,
	"group_guardian":    1,
	"channel_commander": 1,
	"empire_builder":    10,
	"week_warrior":      7,
	"month_master":      30,
	"legendary":         100,
	"early_adopter":     1,
	"premium_user":      1,
	"bug_hunter":        1,
}

func (db *Database) GetAchievements(ctx context.Context, userID int64) ([]model.UserAchievement, error) {
	rows, err := db.Pool.Query(ctx, "SELECT achievement_id, progress, unlocked, unlocked_at FROM user_achievements WHERE user_id = $1", userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	userProgress := make(map[string]model.UserAchievement)
	for rows.Next() {
		var achID string
		var progress int
		var unlocked bool
		var unlockedAt *time.Time
		if err := rows.Scan(&achID, &progress, &unlocked, &unlockedAt); err == nil {
			target := PredefinedAchievements[achID]
			if target == 0 {
				target = 1
			}
			userProgress[achID] = model.UserAchievement{
				ID:         achID,
				Unlocked:   unlocked,
				UnlockedAt: unlockedAt,
				Progress:   progress,
				Target:     target,
			}
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	achievementsList := []model.UserAchievement{}
	keys := make([]string, 0, len(PredefinedAchievements))
	for k := range PredefinedAchievements {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	for _, k := range keys {
		if ach, exists := userProgress[k]; exists {
			achievementsList = append(achievementsList, ach)
		} else {
			achievementsList = append(achievementsList, model.UserAchievement{
				ID:       k,
				Unlocked: false,
				Progress: 0,
				Target:   PredefinedAchievements[k],
			})
		}
	}

	return achievementsList, nil
}

func (db *Database) UpdateAchievementProgress(ctx context.Context, userID int64, achievementID string, progress int) error {
	target, ok := PredefinedAchievements[achievementID]
	if !ok {
		return fmt.Errorf("unknown achievement %s", achievementID)
	}

	unlocked := progress >= target
	var unlockedAt *time.Time
	if unlocked {
		t := time.Now()
		unlockedAt = &t
	}

	query := `
		INSERT INTO user_achievements (user_id, achievement_id, progress, unlocked, unlocked_at)
		VALUES ($1, $2, $3, $4, $5)
		ON CONFLICT (user_id, achievement_id) DO UPDATE SET
			progress = GREATEST(user_achievements.progress, EXCLUDED.progress),
			unlocked = CASE WHEN user_achievements.unlocked = TRUE THEN TRUE ELSE EXCLUDED.unlocked END,
			unlocked_at = CASE WHEN user_achievements.unlocked = TRUE THEN user_achievements.unlocked_at ELSE EXCLUDED.unlocked_at END
	`
	_, err := db.Pool.Exec(ctx, query, userID, achievementID, progress, unlocked, unlockedAt)
	return err
}

// MaintainUserStats maintains user streak and days active atomically.
func (db *Database) MaintainUserStats(ctx context.Context, userID int64) error {
	if err := db.EnsureStatsExists(ctx, userID); err != nil {
		return err
	}

	query := `
		UPDATE user_stats SET
			current_streak = CASE
				WHEN CURRENT_DATE - last_active_at::DATE > 1 THEN 1
				WHEN CURRENT_DATE - last_active_at::DATE = 1 THEN current_streak + 1
				ELSE current_streak
			END,
			days_active = CASE
				WHEN CURRENT_DATE - last_active_at::DATE > 0 THEN days_active + 1
				ELSE days_active
			END,
			last_active_at = CASE
				WHEN CURRENT_DATE - last_active_at::DATE > 0 THEN now()
				ELSE last_active_at
			END
		WHERE user_id = $1
	`
	_, err := db.Pool.Exec(ctx, query, userID)
	return err
}

// ExpirePremiumSubscriptions updates all expired premium subscriptions bulk.
func (db *Database) ExpirePremiumSubscriptions(ctx context.Context) error {
	query := `
		UPDATE users SET is_premium = FALSE
		WHERE is_premium = TRUE AND premium_until IS NOT NULL AND premium_until < now()
	`
	_, err := db.Pool.Exec(ctx, query)
	return err
}

type AchievementProgress struct {
	ID       string
	Progress int
}

// BatchUpdateAchievements updates multiple achievements in a single roundtrip to database.
func (db *Database) BatchUpdateAchievements(ctx context.Context, userID int64, items []AchievementProgress) error {
	if len(items) == 0 {
		return nil
	}

	var values []string
	var args []interface{}
	args = append(args, userID)

	for _, item := range items {
		target, ok := PredefinedAchievements[item.ID]
		if !ok {
			target = 1
		}
		unlocked := item.Progress >= target

		var unlockedAt *time.Time
		if unlocked {
			t := time.Now()
			unlockedAt = &t
		}

		idxUser := 1
		idxAch := len(args) + 1
		idxProg := len(args) + 2
		idxUnl := len(args) + 3
		idxUnlAt := len(args) + 4

		values = append(values, fmt.Sprintf("($%d, $%d, $%d, $%d, $%d)", idxUser, idxAch, idxProg, idxUnl, idxUnlAt))
		args = append(args, item.ID, item.Progress, unlocked, unlockedAt)
	}

	query := fmt.Sprintf(`
		INSERT INTO user_achievements (user_id, achievement_id, progress, unlocked, unlocked_at)
		VALUES %s
		ON CONFLICT (user_id, achievement_id) DO UPDATE SET
			progress = GREATEST(user_achievements.progress, EXCLUDED.progress),
			unlocked = user_achievements.unlocked OR EXCLUDED.unlocked,
			unlocked_at = COALESCE(user_achievements.unlocked_at, EXCLUDED.unlocked_at)
	`, strings.Join(values, ", "))

	_, err := db.Pool.Exec(ctx, query, args...)
	return err
}

func (db *Database) GetReferralData(ctx context.Context, userID int64) (*model.ReferralHubData, error) {
	g, ctx := errgroup.WithContext(ctx)

	var code string
	g.Go(func() error {
		code = fmt.Sprintf("ref_%d", userID)
		var refCode sql.NullString
		_ = db.Pool.QueryRow(ctx, "SELECT referral_code FROM users WHERE telegram_id = $1", userID).Scan(&refCode)
		if !refCode.Valid || refCode.String == "" {
			secCode, err := generateSecureReferralCode(8)
			if err == nil {
				_, _ = db.Pool.Exec(ctx, "UPDATE users SET referral_code = $1 WHERE telegram_id = $2", secCode, userID)
			}
		}
		return nil
	})

	var friends []model.ReferralFriend
	var totalInvited int
	var totalEarned float64

	// Count total invited
	g.Go(func() error {
		err := db.Pool.QueryRow(ctx, "SELECT COUNT(*) FROM users WHERE referred_by = $1", userID).Scan(&totalInvited)
		if err != nil {
			return err
		}
		totalEarned = float64(totalInvited) * 1000.0
		return nil
	})

	g.Go(func() error {
		friendsQuery := `
			SELECT u.telegram_id, COALESCE(u.username, u.first_name), u.created_at,
			       1000.0 AS total_earned,
			       COALESCE(us.airdrop_coins, 0),
			       (SELECT COUNT(*) FROM users u2 WHERE u2.referred_by = u.telegram_id) as frens_count
			FROM users u
			LEFT JOIN user_stats us ON u.telegram_id = us.user_id
			WHERE u.referred_by = $1
			ORDER BY us.xp DESC NULLS LAST LIMIT 100
		`
		rows, err := db.Pool.Query(ctx, friendsQuery, userID)
		if err != nil {
			return err
		}
		defer rows.Close()

		friends = []model.ReferralFriend{}
		for rows.Next() {
			var friendID int64
			var name string
			var joinedAt time.Time
			var earned float64
			var airdropCoins float64
			var frensCount int
			if err := rows.Scan(&friendID, &name, &joinedAt, &earned, &airdropCoins, &frensCount); err == nil {
				friends = append(friends, model.ReferralFriend{
					ID:           friendID,
					Name:         name,
					JoinedAt:     joinedAt,
					Earned:       earned,
					AirdropCoins: airdropCoins,
					FrensCount:   frensCount,
				})
			}
		}
		if err := rows.Err(); err != nil {
			return err
		}
		return nil
	})

	if err := g.Wait(); err != nil {
		return nil, err
	}

	return &model.ReferralHubData{
		ReferralCode: code,
		TotalInvited: totalInvited,
		TotalEarned:  totalEarned,
		Friends:      friends,
	}, nil
}

func (db *Database) SetReferredBy(ctx context.Context, userID int64, referrerCode string) (bool, error) {
	var referrerID int64

	// Support fallback frontend code format `ref_<user_id>`
	if strings.HasPrefix(referrerCode, "ref_") {
		idStr := strings.TrimPrefix(referrerCode, "ref_")
		if id, err := strconv.ParseInt(idStr, 10, 64); err == nil {
			referrerID = id
		}
	}

	if referrerID == 0 {
		// Find referrer by 8-char referral_code
		err := db.Pool.QueryRow(ctx, "SELECT telegram_id FROM users WHERE referral_code = $1", referrerCode).Scan(&referrerID)
		if err != nil {
			if err == pgx.ErrNoRows {
				return false, fmt.Errorf("invalid referral code")
			}
			return false, err
		}
	} else {
		// Verify that the parsed referrerID actually exists
		var exists bool
		err := db.Pool.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM users WHERE telegram_id = $1)", referrerID).Scan(&exists)
		if err != nil || !exists {
			return false, fmt.Errorf("invalid referral user id")
		}
	}

	if referrerID == userID {
		return false, fmt.Errorf("cannot refer yourself")
	}

	// Update user's referred_by if it is currently NULL
	cmdTag, err := db.Pool.Exec(ctx, `
		UPDATE users 
		SET referred_by = $1 
		WHERE telegram_id = $2 
		  AND referred_by IS NULL
	`, referrerID, userID)
	if err != nil {
		return false, err
	}

	success := cmdTag.RowsAffected() == 1
	if success {
		// Give 10,000 Coins to both referrer and the new user
		_, _ = db.AdjustAirdropCoins(ctx, referrerID, 10000.0)
		_, _ = db.AdjustAirdropCoins(ctx, userID, 10000.0)
	}

	return success, nil
}

const base62Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

func generateSecureReferralCode(length int) (string, error) {
	result := make([]byte, length)
	for i := 0; i < length; i++ {
		num, err := rand.Int(rand.Reader, big.NewInt(int64(len(base62Chars))))
		if err != nil {
			return "", err
		}
		result[i] = base62Chars[num.Int64()]
	}
	return string(result), nil
}

var LevelThresholds = []int{
	0,            // Level 1: Bronze
	50000,        // Level 2: Silver
	250000,       // Level 3: Gold
	1000000,      // Level 4: Platinum
	5000000,      // Level 5: Diamond
	25000000,     // Level 6: Legendary
	100000000,    // Level 7: Master
	500000000,    // Level 8: Grandmaster
	2500000000,   // Level 9: Elite
	10000000000,  // Level 10: Champion
	50000000000,  // Level 11: Hero
	250000000000, // Level 12: Mythic
}

func GetLevelFromXP(xp int) int {
	level := 1
	for i, req := range LevelThresholds {
		if xp >= req {
			level = i + 1
		} else {
			break
		}
	}
	return level
}

func GetXPToNextLevel(level int) int {
	if level <= 0 {
		return 0
	}
	if level >= len(LevelThresholds) {
		return LevelThresholds[len(LevelThresholds)-1] // Cap at Max Level XP
	}
	return LevelThresholds[level] // LevelThresholds[level] is the XP needed for level + 1 (0-indexed)
}

// PredefinedCosmetics holds all profile cosmetic shop items
var PredefinedCosmetics = []model.CosmeticItem{
	{ID: "gold_shimmer", Type: "border", Name: "Gold Shimmer", Cost: 15000.0, BorderClass: "border-gold-shimmer"},
	{ID: "cyber_glow", Type: "border", Name: "Cyber Glow", Cost: 35000.0, BorderClass: "border-cyber-glow"},
	{ID: "rainbow_wave", Type: "border", Name: "Rainbow Wave", Cost: 75000.0, BorderClass: "border-rainbow-wave"},
	{ID: "cosmic_void", Type: "skin", Name: "Cosmic Void", Cost: 25000.0, SkinClass: "bg-cosmic-void"},
	{ID: "neon_matrix", Type: "skin", Name: "Neon Matrix", Cost: 50000.0, SkinClass: "bg-neon-matrix"},
}

// GetCosmetics gets all cosmetics indicating which ones are purchased by the user
func (db *Database) GetCosmetics(ctx context.Context, userID int64) ([]model.CosmeticItem, error) {
	rows, err := db.Pool.Query(ctx, "SELECT cosmetic_id FROM user_cosmetics WHERE user_id = $1", userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	purchased := make(map[string]bool)
	for rows.Next() {
		var cid string
		if err := rows.Scan(&cid); err == nil {
			purchased[cid] = true
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	result := make([]model.CosmeticItem, len(PredefinedCosmetics))
	for i, item := range PredefinedCosmetics {
		item.Purchased = purchased[item.ID]
		result[i] = item
	}
	return result, nil
}

// HasCosmetic checks if user has purchased the cosmetic
func (db *Database) HasCosmetic(ctx context.Context, userID int64, cosmeticID string) (bool, error) {
	var exists bool
	err := db.Pool.QueryRow(ctx, "SELECT EXISTS(SELECT 1 FROM user_cosmetics WHERE user_id = $1 AND cosmetic_id = $2)", userID, cosmeticID).Scan(&exists)
	return exists, err
}

// RecordCosmeticPurchase inserts the purchased cosmetic
func (db *Database) RecordCosmeticPurchase(ctx context.Context, userID int64, cosmeticID string) error {
	_, err := db.Pool.Exec(ctx, "INSERT INTO user_cosmetics (user_id, cosmetic_id) VALUES ($1, $2) ON CONFLICT DO NOTHING", userID, cosmeticID)
	return err
}

// EquipCosmetic equips the border or skin for the user
func (db *Database) EquipCosmetic(ctx context.Context, userID int64, cosmeticID string, cosmeticType string) error {
	var query string
	switch cosmeticType {
	case "border":
		query = "UPDATE user_stats SET equipped_border = $1 WHERE user_id = $2"
	case "skin":
		query = "UPDATE user_stats SET equipped_skin = $1 WHERE user_id = $2"
	default:
		return fmt.Errorf("invalid cosmetic type: %s", cosmeticType)
	}
	_, err := db.Pool.Exec(ctx, query, cosmeticID, userID)
	return err
}

// SetEmojiStatus sets the user's custom status emoji
func (db *Database) SetEmojiStatus(ctx context.Context, userID int64, emoji string) error {
	_, err := db.Pool.Exec(ctx, "UPDATE user_stats SET emoji_status = $1 WHERE user_id = $2", emoji, userID)
	return err
}

// UpdateUserPremium adds premium duration to a user
func (db *Database) UpdateUserPremium(ctx context.Context, userID int64, duration time.Duration) error {
	var currentPremiumUntil *time.Time
	err := db.Pool.QueryRow(ctx, "SELECT premium_until FROM users WHERE telegram_id = $1", userID).Scan(&currentPremiumUntil)
	if err != nil && err != pgx.ErrNoRows {
		return err
	}

	newUntil := time.Now().Add(duration)
	if currentPremiumUntil != nil && currentPremiumUntil.After(time.Now()) {
		newUntil = currentPremiumUntil.Add(duration)
	}

	_, err = db.Pool.Exec(ctx, "UPDATE users SET is_premium = TRUE, premium_until = $1 WHERE telegram_id = $2", newUntil, userID)
	return err
}

// GetReferralChain gets the Tier 1 and Tier 2 referrers of a user
func (db *Database) GetReferralChain(ctx context.Context, userID int64) (int64, int64, error) {
	var t1, t2 *int64
	query := `
		SELECT u1.referred_by, u2.referred_by
		FROM users u1
		LEFT JOIN users u2 ON u1.referred_by = u2.telegram_id
		WHERE u1.telegram_id = $1
	`
	err := db.Pool.QueryRow(ctx, query, userID).Scan(&t1, &t2)
	if err != nil {
		if err == pgx.ErrNoRows {
			return 0, 0, nil
		}
		return 0, 0, err
	}
	var referrerID, grandparentID int64
	if t1 != nil {
		referrerID = *t1
	}
	if t2 != nil {
		grandparentID = *t2
	}
	return referrerID, grandparentID, nil
}

// AdjustAirdropCoins increments or decrements the user's airdrop_coins directly
func (db *Database) AdjustAirdropCoins(ctx context.Context, userID int64, amount float64) (float64, error) {
	if db.Pool == nil {
		return 0, fmt.Errorf("no database connection")
	}

	// Create user_stats if missing, then adjust
	query := `
		INSERT INTO user_stats (user_id, xp, level, current_streak, last_active_at, energy, energy_updated_at, airdrop_coins, total_coins_earned)
		VALUES ($1, 0, 1, 0, CURRENT_TIMESTAMP, 500, CURRENT_TIMESTAMP, $2::float8, GREATEST(0.0, $2::float8))
		ON CONFLICT (user_id) DO UPDATE 
		SET airdrop_coins = COALESCE(user_stats.airdrop_coins, 0.0) + $2::float8,
		    total_coins_earned = COALESCE(user_stats.total_coins_earned, 0.0) + CASE WHEN $2::float8 > 0 THEN $2::float8 ELSE 0.0 END
		RETURNING airdrop_coins
	`
	var newBalance float64
	err := db.Pool.QueryRow(ctx, query, userID, amount).Scan(&newBalance)
	return newBalance, err
}
