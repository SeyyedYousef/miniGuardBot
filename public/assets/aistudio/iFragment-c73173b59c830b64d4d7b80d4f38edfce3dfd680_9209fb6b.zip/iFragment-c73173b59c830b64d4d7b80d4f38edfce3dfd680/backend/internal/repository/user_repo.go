package repository

import (
	"context"
)

type User struct {
	TelegramID   int64
	Username     string
	FirstName    string
	LastName     string
	LanguageCode string
	IsPremium    bool
	PhotoURL     string
}

func (db *Database) UpsertUser(ctx context.Context, u User) error {
	query := `
		INSERT INTO users (telegram_id, username, first_name, last_name, language_code, is_premium, photo_url)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		ON CONFLICT (telegram_id) DO UPDATE SET
			username = EXCLUDED.username,
			first_name = EXCLUDED.first_name,
			last_name = EXCLUDED.last_name,
			is_premium = EXCLUDED.is_premium,
			photo_url = COALESCE(NULLIF(EXCLUDED.photo_url, ''), users.photo_url),
			language_code = CASE WHEN users.language_manual = true THEN users.language_code ELSE EXCLUDED.language_code END,
			updated_at = CURRENT_TIMESTAMP
	`
	_, err := db.Pool.Exec(ctx, query, u.TelegramID, u.Username, u.FirstName, u.LastName, u.LanguageCode, u.IsPremium, u.PhotoURL)
	return err
}

// GetUserLanguage retrieves the preferred language code for a user by telegram ID
func (db *Database) GetUserLanguage(ctx context.Context, telegramID int64) (string, error) {
	var lang string
	query := `SELECT language_code FROM users WHERE telegram_id = $1`
	err := db.Pool.QueryRow(ctx, query, telegramID).Scan(&lang)
	return lang, err
}

// UpdateUserLanguage manually updates the user's language and sets the manual flag to true
func (db *Database) UpdateUserLanguage(ctx context.Context, telegramID int64, lang string) error {
	query := `
		UPDATE users 
		SET language_code = $2, language_manual = true, updated_at = CURRENT_TIMESTAMP
		WHERE telegram_id = $1
	`
	_, err := db.Pool.Exec(ctx, query, telegramID, lang)
	return err
}
