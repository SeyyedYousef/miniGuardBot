package service

import (
	"log/slog"

	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net"
	"os"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"

	"ifragment-backend/internal/client/mtproto"
	"ifragment-backend/internal/middleware"
	"ifragment-backend/internal/model"
	"ifragment-backend/internal/repository"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
)

var promoCodeRe = regexp.MustCompile(`^[A-Z0-9]{4,20}$`)

type OwnerService struct {
	repo         *repository.OwnerRepo
	cache        *repository.Cache
	settingsRepo *repository.SettingsRepo
	ubManager    *mtproto.UserbotManager
}

func NewOwnerService(repo *repository.OwnerRepo, cache *repository.Cache, settingsRepo *repository.SettingsRepo, ubManager *mtproto.UserbotManager) *OwnerService {
	return &OwnerService{
		repo:         repo,
		cache:        cache,
		settingsRepo: settingsRepo,
		ubManager:    ubManager,
	}
}

// Authenticate verifies the owner password and generates a JWT token for the owner
func (s *OwnerService) Authenticate(ctx context.Context, telegramUserID int64, password string, ip string, ua string) (string, error) {
	// 1. Verify if user is in OWNER_TELEGRAM_IDS
	ownerIDsStr := os.Getenv("OWNER_TELEGRAM_IDS")
	if ownerIDsStr == "" {
		return "", errors.New("admin panel security not configured on server (missing OWNER_TELEGRAM_IDS)")
	}

	isAllowed := false
	for _, idStr := range strings.Split(ownerIDsStr, ",") {
		idStr = strings.TrimSpace(idStr)
		if id, err := strconv.ParseInt(idStr, 10, 64); err == nil && id == telegramUserID {
			isAllowed = true
			break
		}
	}

	if !isAllowed {
		return "", errors.New("unauthorized: telegram user is not registered as owner")
	}

	// Rate limit: Max 5 failed attempts per 15 minutes per IP and per Telegram ID
	if s.cache != nil && s.cache.Client != nil {
		ipLockKey := fmt.Sprintf("owner:login:attempts:ip:%s", ip)
		userLockKey := fmt.Sprintf("owner:login:attempts:user:%d", telegramUserID)

		pipe := s.cache.Client.Pipeline()
		ipGet := pipe.Get(ctx, ipLockKey)
		userGet := pipe.Get(ctx, userLockKey)
		_, _ = pipe.Exec(ctx)

		if val, err := ipGet.Int(); err == nil && val >= 5 {
			return "", errors.New("too many login attempts from this IP; locked temporarily for 15 minutes")
		}
		if val, err := userGet.Int(); err == nil && val >= 5 {
			return "", errors.New("too many login attempts for this account; locked temporarily for 15 minutes")
		}
	}

	incrLoginAttempts := func() {
		if s.cache != nil && s.cache.Client != nil {
			ipLockKey := fmt.Sprintf("owner:login:attempts:ip:%s", ip)
			userLockKey := fmt.Sprintf("owner:login:attempts:user:%d", telegramUserID)

			pipe := s.cache.Client.Pipeline()
			pipe.Incr(ctx, ipLockKey)
			pipe.Expire(ctx, ipLockKey, 15*time.Minute)
			pipe.Incr(ctx, userLockKey)
			pipe.Expire(ctx, userLockKey, 15*time.Minute)
			_, _ = pipe.Exec(ctx)
		}
	}

	// 2. Throw critical configuration error if OWNER_PASSWORD env is missing
	ownerPassword := os.Getenv("OWNER_PASSWORD")
	if ownerPassword == "" {
		incrLoginAttempts()
		return "", errors.New("OWNER_PASSWORD is not configured on the server; refusing to authenticate")
	}

	// Enforce password complexity (at least one letter, one number, and one symbol)
	hasLetter := regexp.MustCompile(`[a-zA-Z]`).MatchString(ownerPassword)
	hasNumber := regexp.MustCompile(`[0-9]`).MatchString(ownerPassword)
	hasSymbol := regexp.MustCompile(`[^a-zA-Z0-9]`).MatchString(ownerPassword)
	if !hasLetter || !hasNumber || !hasSymbol {
		incrLoginAttempts()
		return "", errors.New("server misconfiguration: OWNER_PASSWORD must contain letters, numbers, and symbols")
	}

	// 3. Fetch owner role (throw error if role is not pre-registered in DB - no auto-seeding)
	o, err := s.repo.GetOwnerRole(ctx, telegramUserID)
	if err != nil {
		incrLoginAttempts()
		return "", err
	}

	if o == nil {
		// Auto-seed owner role if they are successfully verified by env vars
		o = &model.OwnerRole{
			TelegramUserID: telegramUserID,
			Role:           "super_admin",
			TotpSecret:     "auto_generated",
		}
		if err := s.repo.UpsertOwnerRole(ctx, o); err != nil {
			incrLoginAttempts()
			return "", fmt.Errorf("failed to auto-seed owner role: %w", err)
		}
	}

	// 4. IP whitelist validation
	if len(o.IPWhitelist) > 0 {
		clientIP := ip
		if host, _, err := net.SplitHostPort(clientIP); err == nil {
			clientIP = host
		}
		allowed := false
		for _, cidr := range o.IPWhitelist {
			if _, ipnet, parseErr := net.ParseCIDR(cidr); parseErr == nil {
				if ipnet.Contains(net.ParseIP(clientIP)) {
					allowed = true
					break
				}
			} else if cidr == clientIP { // exact IP match
				allowed = true
				break
			}
		}
		if !allowed {
			incrLoginAttempts()
			return "", errors.New("IP address not allowed by IP whitelist")
		}
	}

	// 5. Verify Password
	if password != ownerPassword {
		incrLoginAttempts()
		return "", errors.New("invalid password")
	}

	// 6. Reset login failure attempts on successful authentication
	if s.cache != nil && s.cache.Client != nil {
		ipLockKey := fmt.Sprintf("owner:login:attempts:ip:%s", ip)
		userLockKey := fmt.Sprintf("owner:login:attempts:user:%d", telegramUserID)
		pipe := s.cache.Client.Pipeline()
		pipe.Del(ctx, ipLockKey)
		pipe.Del(ctx, userLockKey)
		_, _ = pipe.Exec(ctx)
	}

	// 7. Update last login
	now := time.Now()
	o.LastLoginAt = &now
	if err := s.repo.UpsertOwnerRole(ctx, o); err != nil {
		return "", err
	}

	// 8. Generate Owner JWT Token (Valid for 15 minutes with super admin specific claims)
	claims := middleware.JWTClaims{
		UserID:      telegramUserID,
		Username:    "owner",
		Role:        o.Role,
		TokenType:   "owner",
		MFAVerified: true,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(15 * time.Minute)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, err := token.SignedString([]byte(os.Getenv("JWT_SECRET")))
	if err != nil {
		return "", err
	}

	// 9. Log Audit Event
	payload, _ := json.Marshal(map[string]interface{}{"ip": ip, "user_agent": ua})
	if err := s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:   telegramUserID,
		Action:    "login",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}); err != nil {
		return "", fmt.Errorf("failed to log login audit: %v", err)
	}

	return signed, nil
}

func (s *OwnerService) FlagUser(ctx context.Context, ownerID int64, targetUserID int64, isFlagged bool, reason string, ip string, ua string) error {
	return s.repo.FlagUser(ctx, ownerID, targetUserID, isFlagged, reason, ip, ua)
}

// Stats & Auditing
func (s *OwnerService) GetDashboardStats(ctx context.Context) (*model.OwnerDashboardStats, error) {
	// Redis caching layer (30 seconds) to prevent heavy database load on dashboard refresh
	if s.cache != nil && s.cache.Client != nil {
		cached, err := s.cache.Client.Get(ctx, "owner_dashboard_stats").Result()
		if err == nil && cached != "" {
			var stats model.OwnerDashboardStats
			if json.Unmarshal([]byte(cached), &stats) == nil {
				return &stats, nil
			}
		}
	}

	stats, err := s.repo.GetDashboardStats(ctx)
	if err != nil {
		return nil, err
	}

	if s.cache != nil && s.cache.Client != nil {
		data, err := json.Marshal(stats)
		if err == nil {
			s.cache.Client.Set(ctx, "owner_dashboard_stats", data, 30*time.Second)
		}
	}

	return stats, nil
}

func (s *OwnerService) AdminListCombos(ctx context.Context) ([]repository.DailyCombo, error) {
	return s.repo.DB().AdminListCombos(ctx)
}

func (s *OwnerService) AdminCreateCombo(ctx context.Context, dateStr string, word string, reward int64) error {
	date, err := time.Parse("2006-01-02", dateStr)
	if err != nil {
		return fmt.Errorf("invalid date format: %v", err)
	}
	return s.repo.DB().AdminUpsertCombo(ctx, date, word, reward)
}

func (s *OwnerService) SetUserBan(ctx context.Context, ownerID int64, targetUserID int64, banType string, reason string, durationSeconds int64, ip string, ua string) error {
	var expiresAt *time.Time
	if durationSeconds > 0 {
		exp := time.Now().Add(time.Duration(durationSeconds) * time.Second)
		expiresAt = &exp
	}

	ban := &model.UserBan{
		UserID:    targetUserID,
		BanType:   banType,
		Reason:    reason,
		BannedBy:  ownerID,
		BannedAt:  time.Now(),
		ExpiresAt: expiresAt,
	}

	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	if err := s.repo.SetUserBanTx(ctx, tx, ban); err != nil {
		return err
	}

	// Log Audit Event INSIDE the same transaction
	payload, _ := json.Marshal(map[string]interface{}{
		"ban_type": banType,
		"reason":   reason,
		"expires":  expiresAt,
	})

	auditLog := &model.OwnerAuditLog{
		OwnerID:      ownerID,
		Action:       "ban_user",
		TargetUserID: &targetUserID,
		Payload:      payload,
		IPAddress:    ip,
		UserAgent:    ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) RemoveUserBan(ctx context.Context, ownerID int64, targetUserID int64, ip string, ua string) error {
	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	if err := s.repo.RemoveUserBanTx(ctx, tx, targetUserID); err != nil {
		return err
	}

	// Log Audit Event INSIDE the same transaction
	auditLog := &model.OwnerAuditLog{
		OwnerID:      ownerID,
		Action:       "unban_user",
		TargetUserID: &targetUserID,
		IPAddress:    ip,
		UserAgent:    ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) ImpersonateUser(ctx context.Context, ownerID int64, targetUserID int64, ip string, ua string) (string, error) {
	// Block impersonating another owner/administrator of the bot
	isTargetAdmin, err := s.repo.GetOwnerRole(ctx, targetUserID)
	if err == nil && isTargetAdmin != nil {
		return "", errors.New("forbidden: administrators cannot be impersonated under any circumstances")
	}

	ownerIDsStr := os.Getenv("OWNER_TELEGRAM_IDS")
	if ownerIDsStr != "" {
		for _, idStr := range strings.Split(ownerIDsStr, ",") {
			idStr = strings.TrimSpace(idStr)
			if id, err := strconv.ParseInt(idStr, 10, 64); err == nil && id == targetUserID {
				return "", errors.New("forbidden: administrators cannot be impersonated under any circumstances")
			}
		}
	}

	// Create database impersonation session
	sessionID := uuid.NewString()
	sess := &model.ImpersonationSession{
		ID:           sessionID,
		OwnerID:      ownerID,
		TargetUserID: targetUserID,
		StartedAt:    time.Now(),
	}

	if err := s.repo.CreateImpersonationSession(ctx, sess); err != nil {
		return "", err
	}

	// Generate Impersonated JWT Token (Valid for 15 minutes)
	claims := middleware.JWTClaims{
		UserID:   targetUserID,
		Username: fmt.Sprintf("impersonated_user_%d", targetUserID),
		Role:     "user", // Standard user role
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(15 * time.Minute)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			ID:        sessionID, // Link token directly to session
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, err := token.SignedString([]byte(os.Getenv("JWT_SECRET")))
	if err != nil {
		return "", err
	}

	// Log Audit Event
	payload, _ := json.Marshal(map[string]interface{}{"session_id": sessionID})
	if err := s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:      ownerID,
		Action:       "impersonate",
		TargetUserID: &targetUserID,
		Payload:      payload,
		IPAddress:    ip,
		UserAgent:    ua,
	}); err != nil {
		return "", fmt.Errorf("failed to log impersonation audit: %v", err)
	}

	return signed, nil
}

func (s *OwnerService) GetAuditLogs(ctx context.Context, limit, offset int) ([]model.OwnerAuditLog, error) {
	return s.repo.GetOwnerAuditLogs(ctx, limit, offset)
}

func (s *OwnerService) SearchUsers(ctx context.Context, query string) ([]repository.SearchUserResult, error) {
	return s.repo.SearchUsers(ctx, query)
}

func (s *OwnerService) CreatePromoCode(ctx context.Context, ownerID int64, code string, amount float64, maxUses int, expiresAt *time.Time, ip string, ua string) error {
	code = strings.ToUpper(code)
	// Domain bounds validation for promo code reward and usage limits (Defense-in-Depth)
	if !promoCodeRe.MatchString(code) {
		return errors.New("code must be 4-20 alphanumeric characters")
	}
	if math.IsNaN(amount) || math.IsInf(amount, 0) || amount <= 0 || amount > 100000 {
		return errors.New("reward_amount must be valid and between 0 and 100000")
	}
	if maxUses <= 0 || maxUses > 1000000 {
		return errors.New("max_uses must be between 0 and 1000000")
	}

	p := model.PromoCode{
		Code:         code,
		RewardAmount: amount,
		MaxUses:      maxUses,
		ExpiresAt:    expiresAt,
	}

	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	if err := s.repo.CreatePromoCodeTx(ctx, tx, p); err != nil {
		return err
	}

	payload, _ := json.Marshal(map[string]interface{}{
		"code":          code,
		"reward_amount": amount,
		"max_uses":      maxUses,
		"expires_at":    expiresAt,
	})

	auditLog := &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "create_promo",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) DeletePromoCode(ctx context.Context, ownerID int64, code string, ip string, ua string) error {
	code = strings.ToUpper(code)
	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	if err := s.repo.DeletePromoCodeTx(ctx, tx, code); err != nil {
		return err
	}

	payload, _ := json.Marshal(map[string]string{"code": code})

	auditLog := &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "delete_promo",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) ListPromoCodes(ctx context.Context) ([]model.PromoCode, error) {
	return s.repo.ListPromoCodes(ctx)
}

func (s *OwnerService) RedeemPromoCode(ctx context.Context, userID int64, code string) error {
	code = strings.ToUpper(code)
	if err := s.repo.RedeemPromoCodeTx(ctx, code, userID); err != nil {
		return err
	}
	if s.cache != nil && s.cache.Client != nil {
		s.cache.Client.Del(ctx, fmt.Sprintf("profile:stats:%d", userID))
	}
	return nil
}

func (s *OwnerService) ListAllQuests(ctx context.Context) ([]model.Quest, error) {
	return s.repo.GetQuests(ctx)
}

func (s *OwnerService) CreateQuest(ctx context.Context, ownerID int64, q model.Quest, ip string, ua string) error {
	if q.Key == "" || q.Title == "" || q.Type == "" {
		return errors.New("quest key, title, and type are required")
	}
	if q.RewardFrg < 0 || q.RewardXp < 0 {
		return errors.New("rewards cannot be negative")
	}

	// Validate type
	validTypes := map[string]bool{
		"channel_join":        true,
		"quiz":                true,
		"referral":            true,
		"first_username_scan": true,
		"register_first_bot":  true,
		"league_gold":         true,
		"join_clan":           true,
		"invite_1_fren":       true,
		"invite_3_frens":      true,
		"invite_10_frens":     true,
		"taps_100k":           true,
		"telegram_premium":    true,
	}
	if !validTypes[q.Type] {
		return fmt.Errorf("invalid quest type: %s", q.Type)
	}

	// For quiz types, if raw answer is passed in config, let's hash it on the server
	if q.Type == "quiz" {
		var config map[string]interface{}
		if err := json.Unmarshal(q.Config, &config); err == nil {
			if answer, ok := config["answer"].(string); ok && answer != "" {
				cleaned := strings.ToLower(strings.TrimSpace(answer))
				hash := sha256.New()
				hash.Write([]byte(cleaned))
				config["quiz_answer_hash"] = hex.EncodeToString(hash.Sum(nil))
				delete(config, "answer") // clear raw answer for security
				q.Config, _ = json.Marshal(config)
			}
		}
	}

	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	// Check if already exists
	existing, err := s.repo.GetQuestByKey(ctx, q.Key)
	if err != nil {
		return err
	}
	if existing != nil {
		return fmt.Errorf("quest with key %s already exists", q.Key)
	}

	if err := s.repo.CreateQuestTx(ctx, tx, q); err != nil {
		return err
	}

	payload, _ := json.Marshal(q)
	auditLog := &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "create_quest",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) UpdateQuest(ctx context.Context, ownerID int64, q model.Quest, ip string, ua string) error {
	if q.Key == "" || q.Title == "" || q.Type == "" {
		return errors.New("quest key, title, and type are required")
	}
	if q.RewardFrg < 0 || q.RewardXp < 0 {
		return errors.New("rewards cannot be negative")
	}

	// Validate type
	validTypes := map[string]bool{
		"channel_join":        true,
		"quiz":                true,
		"referral":            true,
		"first_username_scan": true,
		"register_first_bot":  true,
		"league_gold":         true,
		"join_clan":           true,
		"invite_1_fren":       true,
		"invite_3_frens":      true,
		"invite_10_frens":     true,
		"taps_100k":           true,
		"telegram_premium":    true,
	}
	if !validTypes[q.Type] {
		return fmt.Errorf("invalid quest type: %s", q.Type)
	}

	// For quiz types, if raw answer is passed in config, let's hash it on the server
	if q.Type == "quiz" {
		var config map[string]interface{}
		if err := json.Unmarshal(q.Config, &config); err == nil {
			if answer, ok := config["answer"].(string); ok && answer != "" {
				cleaned := strings.ToLower(strings.TrimSpace(answer))
				hash := sha256.New()
				hash.Write([]byte(cleaned))
				config["quiz_answer_hash"] = hex.EncodeToString(hash.Sum(nil))
				delete(config, "answer") // clear raw answer for security
				q.Config, _ = json.Marshal(config)
			}
		}
	}

	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	// Verify exists
	existing, err := s.repo.GetQuestByKey(ctx, q.Key)
	if err != nil {
		return err
	}
	if existing == nil {
		return fmt.Errorf("quest with key %s not found", q.Key)
	}

	if err := s.repo.UpdateQuestTx(ctx, tx, q); err != nil {
		return err
	}

	payload, _ := json.Marshal(q)
	auditLog := &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "update_quest",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) DeleteQuest(ctx context.Context, ownerID int64, key string, ip string, ua string) error {
	// Begin atomic transaction
	tx, err := s.repo.DB().Pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx)

	// Verify exists
	existing, err := s.repo.GetQuestByKey(ctx, key)
	if err != nil {
		return err
	}
	if existing == nil {
		return fmt.Errorf("quest with key %s not found", key)
	}

	if err := s.repo.DeleteQuestTx(ctx, tx, key); err != nil {
		return err
	}

	payload, _ := json.Marshal(map[string]string{"key": key})
	auditLog := &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "delete_quest",
		Payload:   payload,
		IPAddress: ip,
		UserAgent: ua,
	}
	if err := s.repo.LogOwnerAuditTx(ctx, tx, auditLog); err != nil {
		return err
	}

	return tx.Commit(ctx)
}

func (s *OwnerService) UserbotSendCode(ctx context.Context, phone string) (string, error) {
	return mtproto.AuthSendCode(ctx, phone)
}

func (s *OwnerService) UserbotVerifyCode(ctx context.Context, phone, code, hash string) error {
	err := mtproto.AuthSignIn(ctx, phone, code, hash)
	if err != nil {
		return err
	}

	// Start in the pool
	if s.ubManager != nil {
		if err := s.ubManager.AddClient(ctx, phone); err != nil {
			return err
		}
	}

	// Save to DB
	return s.repo.CreateManagedUserbot(ctx, phone)
}

func (s *OwnerService) ListUserbots(ctx context.Context) ([]model.ManagedUserbot, error) {
	return s.repo.GetActiveManagedUserbots(ctx)
}

func (s *OwnerService) DeleteUserbot(ctx context.Context, id string) error {
	// We need the phone to remove it from the pool. For simplicity, just remove from DB.
	// On next restart, it won't load. Or we can fetch the userbot first.
	// Let's just delete from DB.
	return s.repo.DeleteManagedUserbot(ctx, id)
}

// ─── Finance & Subscriptions ────────────────────────────────────────────────
func (s *OwnerService) GetOrdersList(ctx context.Context, limit, offset int) ([]model.OrderRecord, error) {
	return s.repo.GetOrdersList(ctx, limit, offset)
}

func (s *OwnerService) GetPremiumEntities(ctx context.Context) ([]model.PremiumEntity, error) {
	return s.repo.GetPremiumEntities(ctx)
}

// ─── System Health & Logs ───────────────────────────────────────────────────
func (s *OwnerService) LogSystemError(ctx context.Context, source, message string) error {
	return s.repo.LogSystemError(ctx, source, message)
}

func (s *OwnerService) GetSystemErrors(ctx context.Context, limit int) ([]model.SystemErrorLog, error) {
	return s.repo.GetSystemErrors(ctx, limit)
}

func (s *OwnerService) GetSystemHealthMetrics(ctx context.Context) (model.SystemHealthMetrics, error) {
	var metrics model.SystemHealthMetrics

	// Calculate memory and goroutines
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	metrics.AllocatedMB = m.Alloc / 1024 / 1024
	metrics.TotalSysMB = m.Sys / 1024 / 1024
	metrics.Goroutines = runtime.NumGoroutine()

	// Check DB Ping
	if err := s.repo.DB().Pool.Ping(ctx); err != nil {
		metrics.DBStatus = "disconnected"
	} else {
		metrics.DBStatus = "healthy"
	}

	return metrics, nil
}

// ─── Entities (Channels & Groups) ───────────────────────────────────────────
func (s *OwnerService) GetAllChannels(ctx context.Context, limit, offset int) ([]model.EntityRecord, error) {
	return s.repo.GetAllChannels(ctx, limit, offset)
}

func (s *OwnerService) GetAllGroups(ctx context.Context, limit, offset int) ([]model.EntityRecord, error) {
	return s.repo.GetAllGroups(ctx, limit, offset)
}

type AddEntityCreditRequest struct {
	EntityType string `json:"entity_type"` // "channel" or "group"
	EntityID   string `json:"entity_id"`
	Days       int    `json:"days"`
}

func (s *OwnerService) AddEntityCredit(ctx context.Context, req AddEntityCreditRequest, adminID int64, ip string) error {
	var err error
	duration := time.Duration(req.Days) * 24 * time.Hour
	entityIDUUID, parseErr := uuid.Parse(req.EntityID)
	if parseErr != nil {
		return fmt.Errorf("invalid entity ID: %v", parseErr)
	}

	switch req.EntityType {
	case "channel":
		var current *time.Time
		err = s.repo.DB().Pool.QueryRow(ctx, "SELECT paid_until FROM managed_channels WHERE id = $1", entityIDUUID).Scan(&current)
		if err != nil {
			return err
		}

		newUntil := time.Now().Add(duration)
		if current != nil && current.After(time.Now()) {
			newUntil = current.Add(duration)
		}

		_, err = s.repo.DB().Pool.Exec(ctx, "UPDATE managed_channels SET paid_until = $1, subscription_status = 'premium' WHERE id = $2", newUntil, entityIDUUID)
	case "group":
		var current *time.Time
		err = s.repo.DB().Pool.QueryRow(ctx, "SELECT paid_until FROM managed_groups WHERE id = $1", entityIDUUID).Scan(&current)
		if err != nil {
			return err
		}

		newUntil := time.Now().Add(duration)
		if current != nil && current.After(time.Now()) {
			newUntil = current.Add(duration)
		}

		_, err = s.repo.DB().Pool.Exec(ctx, "UPDATE managed_groups SET paid_until = $1, subscription_status = 'premium' WHERE id = $2", newUntil, entityIDUUID)
	default:
		return fmt.Errorf("invalid entity type: %s", req.EntityType)
	}

	if err != nil {
		return err
	}

	// Audit log
	slog.Info("Owner added credit to entity", "entity_type", req.EntityType, "entity_id", req.EntityID, "days", req.Days, "admin_id", adminID)

	payloadBytes, _ := json.Marshal(map[string]interface{}{
		"entity_type": req.EntityType,
		"entity_id":   req.EntityID,
		"days":        req.Days,
	})

	_ = s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:   adminID,
		Action:    "add_entity_credit",
		Payload:   payloadBytes,
		IPAddress: ip,
	})
	return nil
}

func (s *OwnerService) AdjustAirdropCoins(ctx context.Context, req AdjustAirdropCoinsRequest, adminID int64, ip string) (float64, error) {
	newBalance, err := s.repo.DB().AdjustAirdropCoins(ctx, req.UserID, req.Amount)
	if err != nil {
		return 0, err
	}

	if s.cache != nil && s.cache.Client != nil {
		s.cache.Client.Del(ctx, fmt.Sprintf("profile:stats:%d", req.UserID))
	}

	// Audit log
	slog.Info("Owner adjusted user airdrop coins", "user_id", req.UserID, "amount", req.Amount, "reason", req.Reason, "admin_id", adminID)

	payloadBytes, _ := json.Marshal(map[string]interface{}{
		"amount": req.Amount,
		"reason": req.Reason,
	})

	_ = s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:      adminID,
		Action:       "adjust_airdrop_coins",
		TargetUserID: &req.UserID,
		Payload:      payloadBytes,
		IPAddress:    ip,
	})
	return newBalance, nil
}

type AdjustAirdropCoinsRequest struct {
	UserID int64   `json:"user_id"`
	Amount float64 `json:"amount"`
	Reason string  `json:"reason"`
}

// System Settings Management
func (s *OwnerService) GetSystemSettings(ctx context.Context) (*model.SystemSettings, error) {
	return s.settingsRepo.GetSystemSettings(ctx)
}

func (s *OwnerService) UpdateSystemSettings(ctx context.Context, settings *model.SystemSettings, ownerID int64, ip, ua string) error {
	// First fetch the existing to log the difference
	oldSettings, _ := s.settingsRepo.GetSystemSettings(ctx)

	err := s.settingsRepo.UpdateSystemSettings(ctx, settings)
	if err != nil {
		return err
	}

	// Audit Logging
	payload := map[string]interface{}{
		"old": oldSettings,
		"new": settings,
	}
	payloadBytes, _ := json.Marshal(payload)
	_ = s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "update_system_settings",
		Payload:   payloadBytes,
		IPAddress: ip,
		UserAgent: ua,
	})

	return nil
}

// Broadcasts
func (s *OwnerService) CreateBroadcast(ctx context.Context, ownerID int64, targetAudience, message, ip, ua string) (string, error) {
	if targetAudience == "" || message == "" {
		return "", errors.New("target_audience and message are required")
	}

	id, err := s.repo.CreateBroadcast(ctx, ownerID, targetAudience, message)
	if err != nil {
		return "", err
	}

	// Log audit
	payloadBytes, _ := json.Marshal(map[string]string{
		"broadcast_id":    id,
		"target_audience": targetAudience,
	})
	_ = s.repo.LogOwnerAudit(ctx, &model.OwnerAuditLog{
		OwnerID:   ownerID,
		Action:    "create_broadcast",
		Payload:   payloadBytes,
		IPAddress: ip,
		UserAgent: ua,
	})

	return id, nil
}

func (s *OwnerService) ListBroadcasts(ctx context.Context) ([]model.Broadcast, error) {
	return s.repo.ListBroadcasts(ctx)
}
